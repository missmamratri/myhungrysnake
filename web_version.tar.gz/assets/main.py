import pygame, random, math, time, sys
import asyncio
from pygame.locals import QUIT, MOUSEBUTTONDOWN

pygame.init()

width_screen, height_screen = 400, 300
window = pygame.display.set_mode((width_screen, height_screen))
pygame.display.set_caption("hungry Snake")

white = (255, 255, 255)
black = (0, 0, 0)
magenta_soft = (255, 119, 238)
blue = (0, 0, 255)
red = (255, 0, 0)

# Memuat Gambar
snake_image = pygame.image.load("biru2.png")
food_image = pygame.image.load("jeruk.png").convert_alpha()
special_food = pygame.image.load("strawberry.png").convert_alpha()
backdrop_play = pygame.image.load("background.png")
bomb_image = pygame.image.load("bomb.png")
intro_image = pygame.image.load("intro.png")
intro_image = pygame.transform.scale(intro_image, (width_screen, height_screen))

gridsize = 20
snake_image = pygame.transform.scale(snake_image, (gridsize, gridsize))
food_image = pygame.transform.scale(food_image, (gridsize + 7, gridsize + 7))
special_food = pygame.transform.scale(special_food, (gridsize + 7, gridsize + 7))
bomb_image = pygame.transform.scale(bomb_image, (gridsize, gridsize))
backdrop_play = pygame.transform.scale(backdrop_play, (width_screen, height_screen))

# Menginisialisasi audio dengan aman (menggunakan mp3 sesuai config thonny Anda)
pygame.mixer.music.load("Video Game 1.ogg")
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(-1)

eat_sound = pygame.mixer.Sound("Bite.ogg")
gameover_sound = pygame.mixer.Sound("Oops.ogg")

class Snake:
    def __init__(self, speed):
        self.body = [(width_screen // 2 - i * 20, height_screen // 2) for i in range(4)]
        self.direction = (1, 0)
        self.speed = speed
    
    def set_speed(self, speed):
        self.speed = speed
    
    def move(self):
        dx, dy = self.direction
        # PERBAIKAN: Mengembalikan indeks koordinat [0] dan [1] agar matematika Python valid
        new_head = ((self.body[0][0] + dx * 20) % width_screen, (self.body[0][1] + dy * 20) % height_screen)
        self.body.pop()
        self.body.insert(0, new_head)
    
    def grow(self):
        dx, dy = self.direction
        # PERBAIKAN: Mengembalikan indeks koordinat agar matematika Python valid
        new_tail = ((self.body[-1][0] + dx * 20) % width_screen, (self.body[-1][1] + dy * 20) % height_screen)
        self.body.append(new_tail)
        
    def change_direction(self, dx, dy):
        if (dx, dy) != (-self.direction[0], -self.direction[1]):
            self.direction = (dx, dy)
    
    def get_head(self):
        return self.body[0]
    
    def get_body(self):
        return self.body[1:]
    
class Food:
    def __init__(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    
    def respawn(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    
    def get_position(self):
        return self.position
    
class SpecialFood:
    def __init__(self):
        self.respawn()
    
    def respawn(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    
    def get_position(self):
        return self.position
    
class Bomb:
    def __init__(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    
    def respawn(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    
    def get_position(self):
        return self.position

bombs = [Bomb() for _ in range(random.randint(3, 5))]

def distance(point1, point2):
    return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)

# Mengubah intro_screen menjadi fungsi ASYNC agar browser tidak mengunci
async def intro_screen():
    font_small = pygame.font.Font(None, 30)
    
    slow_choice = font_small.render("SLOW", True, black)
    normal_choice = font_small.render("NORMAL", True, black)
    fast_choice = font_small.render("FAST", True, black)
    
    slow_rect = slow_choice.get_rect(center=(width_screen // 4, height_screen // 3 + 120))
    normal_rect = normal_choice.get_rect(center=(width_screen // 2, height_screen // 3 + 120))
    fast_rect = fast_choice.get_rect(center=(width_screen - 100, height_screen // 3 + 120))
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                if slow_rect.collidepoint(x, y):
                    return "slow"
                if normal_rect.collidepoint(x, y):
                    return "normal"
                if fast_rect.collidepoint(x, y):
                    return "fast"
        
        window.blit(intro_image, (0, 0))
        window.blit(slow_choice, slow_rect)
        window.blit(normal_choice, normal_rect)
        window.blit(fast_choice, fast_rect)
        
        pygame.display.update()
        # Wajib memberikan jeda singkat untuk browser di intro loop
        await asyncio.sleep(0)

# Mengubah fungsi main menjadi ASYNC
async def main():
    speed_level = await intro_screen()
    show_special = False
    special_timer = 0

    if speed_level == "slow":
        snake_speed = 5
    elif speed_level == "normal":
        snake_speed = 10
    else:
        snake_speed = 15
        
    snake = Snake(snake_speed)
    food = Food()
    score = 0
    font = pygame.font.SysFont(None, 30)
    specials_food = SpecialFood()
    
    clock = pygame.time.Clock()
    
    # Logika perulangan utama game
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                     
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    snake.change_direction(0, -1)
                if event.key == pygame.K_DOWN:
                    snake.change_direction(0, 1)
                if event.key == pygame.K_LEFT:
                    snake.change_direction(-1, 0)
                if event.key == pygame.K_RIGHT:
                    snake.change_direction(1, 0)
                    
        snake.move()
        head = snake.get_head()

        if distance(head, food.get_position()) < 20:
            food.respawn()
            snake.grow()
            score += 1
            eat_sound.play()
            
        window.blit(backdrop_play, (0, 0))
              
        for segment in snake.body:
            window.blit(snake_image, segment)
        
        window.blit(food_image, food.get_position())
        
        special_timer += 1
        if not show_special and special_timer > 200:
            show_special = True
            specials_food.respawn()
            special_timer = 0

        if show_special:
            window.blit(special_food, specials_food.get_position())

        if show_special and distance(head, specials_food.get_position()) < 20:
            snake.grow()
            eat_sound.play()
            snake.grow()
            eat_sound.play()
            score += 2
            show_special = False

        scoring = font.render(f"Score : {score}", True, black)
        window.blit(scoring, (10, 10))
        
        # Cek tabrakan diri sendiri
        if head in snake.get_body():
            font = pygame.font.SysFont(None, 36)
            text = font.render("Game Over", True, black)
            window.blit(text, (width_screen // 2 - 70, height_screen // 2))
            pygame.display.update()
            gameover_sound.play()
            await asyncio.sleep(2)
            pygame.quit()
            sys.exit()
        
        # Cek tabrakan bom
        for bomb in bombs:
            window.blit(bomb_image, bomb.get_position())
            if distance(head, bomb.get_position()) < gridsize:
                font = pygame.font.SysFont(None, 36)
                text = font.render("Game Over", True, black)
                window.blit(text, (width_screen // 2 - 70, height_screen // 2))
                pygame.display.update()
                gameover_sound.play()
                await asyncio.sleep(2)
                pygame.quit()
                sys.exit()
        
        pygame.display.update()
        clock.tick(snake_speed)
        
        # Wajib memberikan jeda singkat untuk browser di main game loop
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())
