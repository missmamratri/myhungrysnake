import pygame, random, math, time, sys
import asyncio
from pygame.locals import QUIT, MOUSEBUTTONDOWN

# Deteksi apakah game berjalan di browser web
IS_WEB = sys.platform == "emscripten"

# Fungsi JavaScript untuk memutar audio langsung di browser tanpa lag/putus-putus
def play_sound_web(file_path, loop=False):
    if IS_WEB:
        import platform
        loop_str = "true" if loop else "false"
        js_code = f"""
        if (!window.audioCache) window.audioCache = {{}};
        if (!window.audioCache['{file_path}']) {{
            window.audioCache['{file_path}'] = new Audio('{file_path}');
        }}
        let audio = window.audioCache['{file_path}'];
        audio.loop = {loop_str};
        audio.volume = {0.2 if loop else 1.0};
        audio.play().catch(e => console.log("Audio play blocked"));
        """
        platform.window.eval(js_code)
    else:
        # Cadangan jika dimainkan di komputer lokal (Thonny)
        if loop:
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.set_volume(0.2)
            pygame.mixer.music.play(-1)
        else:
            sound = pygame.mixer.Sound(file_path)
            sound.play()

pygame.init()

width_screen, height_screen = 400, 300
window = pygame.display.set_mode((width_screen, height_screen))
pygame.display.set_caption("hungry Snake")

white = (255, 255, 255)
black = (0, 0, 0)

# Memuat Gambar
snake_image = pygame.image.load("biru2.png")
food_image = pygame.image.load("jeruk.png").convert_alpha()
special_food = pygame.image.load("strawberry.png").convert_alpha()
backdrop_play = pygame.image.load("background.png")
bomb_image = pygame.image.load("bomb.png")
intro_image = pygame.image.load("intro.png")
intro_image = pygame.transform.scale(intro_image, (width_screen, height_screen))

gridsize = 20
snake_image = pygame.transform.scale(snake_image, (gridsize, gridsize))
food_image = pygame.transform.scale(food_image, (gridsize + 7, gridsize + 7))
special_food = pygame.transform.scale(special_food, (gridsize + 7, gridsize + 7))
bomb_image = pygame.transform.scale(bomb_image, (gridsize, gridsize))
backdrop_play = pygame.transform.scale(backdrop_play, (width_screen, height_screen))

# Mainkan musik latar di awal
play_sound_web("Video Game 1.ogg", loop=True)

class Snake:
    def __init__(self):
        self.body = [(width_screen // 2 - i * 20, height_screen // 2) for i in range(4)]
        self.direction = (1, 0)
    
    def move(self):
        dx, dy = self.direction
        new_head = ((self.body[0][0] + dx * 20) % width_screen, (self.body[0][1] + dy * 20) % height_screen)
        self.body.pop()
        self.body.insert(0, new_head)
    
    def grow(self):
        dx, dy = self.direction
        new_tail = ((self.body[-1][0] + dx * 20) % width_screen, (self.body[-1][1] + dy * 20) % height_screen)
        self.body.append(new_tail)
        
    def change_direction(self, dx, dy):
        if (dx, dy) != (-self.direction[0], -self.direction[1]):
            self.direction = (dx, dy)
    
    def get_head(self):
        return self.body[0]
    
    def get_body(self):
        return self.body[1:]
    
class Food:
    def __init__(self):
        self.respawn()
    def respawn(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    def get_position(self):
        return self.position
    
class SpecialFood:
    def __init__(self):
        self.respawn()
    def respawn(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    def get_position(self):
        return self.position
    
class Bomb:
    def __init__(self):
        self.respawn()
    def respawn(self):
        self.position = (random.randrange(0, width_screen, 20), random.randrange(0, height_screen, 20))
    def get_position(self):
        return self.position

def distance(point1, point2):
    return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)

async def intro_screen():
    font_small = pygame.font.Font(None, 30)
    slow_choice = font_small.render("SLOW", True, black)
    normal_choice = font_small.render("NORMAL", True, black)
    fast_choice = font_small.render("FAST", True, black)
    
    slow_rect = slow_choice.get_rect(center=(width_screen // 4, height_screen // 3 + 120))
    normal_rect = normal_choice.get_rect(center=(width_screen // 2, height_screen // 3 + 120))
    fast_rect = fast_choice.get_rect(center=(width_screen - 100, height_screen // 3 + 120))
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                if slow_rect.collidepoint(x, y):
                    return "slow"
                if normal_rect.collidepoint(x, y):
                    return "normal"
                if fast_rect.collidepoint(x, y):
                    return "fast"
        
        window.blit(intro_image, (0, 0))
        window.blit(slow_choice, slow_rect)
        window.blit(normal_choice, normal_rect)
        window.blit(fast_choice, fast_rect)
        
        pygame.display.update()
        await asyncio.sleep(0)

async def main():
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 30)
    font_gameover = pygame.font.SysFont(None, 36)
    
    # Master Loop: Menjamin game berputar kembali ke menu awal setelah Game Over
    while True:
        speed_level = await intro_screen()
        
        if speed_level == "slow":
            snake_speed = 6
        elif speed_level == "normal":
            snake_speed = 10
        else:
            snake_speed = 16
            
        # Inisialisasi ulang total objek data game
        snake = Snake()
        food = Food()
        specials_food = SpecialFood()
        bombs = [Bomb() for _ in range(random.randint(3, 5))]
        
        score = 0
        show_special = False
        special_timer = 0
        game_over = False
        
        # Loop Gameplay Aktif
        while not game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                         
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        snake.change_direction(0, -1)
                    if event.key == pygame.K_DOWN:
                        snake.change_direction(0, 1)
                    if event.key == pygame.K_LEFT:
                        snake.change_direction(-1, 0)
                    if event.key == pygame.K_RIGHT:
                        snake.change_direction(1, 0)
            
            snake.move()
            head = snake.get_head()

            # Deteksi Makan
            if distance(head, food.get_position()) < 20:
                food.respawn()
                snake.grow()
                score += 1
                play_sound_web("Bite.ogg")
                
            window.blit(backdrop_play, (0, 0))
                  
            for segment in snake.body:
                window.blit(snake_image, segment)
            
            window.blit(food_image, food.get_position())
            
            # Logika Makanan Spesial
            special_timer += 1
            if not show_special and special_timer > 200:
                show_special = True
                specials_food.respawn()
                special_timer = 0

            if show_special:
                window.blit(special_food, specials_food.get_position())

            if show_special and distance(head, specials_food.get_position()) < 20:
                snake.grow()
                snake.grow()
                play_sound_web("Bite.ogg")
                score += 2
                show_special = False

            scoring = font.render(f"Score : {score}", True, black)
            window.blit(scoring, (10, 10))
            
            # Cek Tabrakan Diri Sendiri
            if head in snake.get_body():
                game_over = True
            
            # Cek Tabrakan Bom
            for bomb in bombs:
                window.blit(bomb_image, bomb.get_position())
                if distance(head, bomb.get_position()) < gridsize:
                    game_over = True
            
            pygame.display.update()
            clock.tick(snake_speed)  # Mengembalikan pengaturan ke FPS asli ular agar sinkron
            await asyncio.sleep(0)
            
        # --- Eksekusi Layar Game Over ---
        text = font_gameover.render("Game Over", True, black)
        window.blit(text, (width_screen // 2 - 70, height_screen // 2))
        pygame.display.update()
        play_sound_web("Oops.ogg")
        
        await asyncio.sleep(2) # Diam selama 2 detik, lalu otomatis kembali ke awal `while True`

if __name__ == "__main__":
    asyncio.run(main())
